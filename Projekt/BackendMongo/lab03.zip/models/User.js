const { Schema, model } = require('mongoose');

// Schema domyślnie dodaje unikalne pole _id, dlatego pomijamy je w deklaracji
const userSchema = new Schema({
    idUser: {type:String},
    login: {type:String},
    email: {type:String},
    registrationDate: {type:Date},
    posts: {type:[{type:Schema.Types.ObjectId,ref: "Post"}]}
});

module.exports = model('User', userSchema);