const { Schema, model } = require('mongoose');

const postSchema = new Schema({
    idPost: {type:Number},
    text: {type:String},
    responses: {type:Number},
    author: {type:Schema.Types.ObjectId,ref:"User"}
    
});

module.exports = model('Post', postSchema);