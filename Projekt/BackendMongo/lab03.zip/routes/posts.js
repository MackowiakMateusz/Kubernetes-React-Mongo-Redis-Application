const express = require('express');
const router = express.Router({mergeParams: true});

const Post = require('../models/Post');

router.get('/', async (req, res) => {
  return res.send({});
});

router.get('/:id', async (req, res) => {
    return res.send({});
});

router.post('/:userId', async (req, res) => {
    return res.send(req.body);
});

router.delete('/:id', async (req, res) => {
  const id = req.params.id;
  return res.send({
    deletedUserId: id
  });
});


module.exports = router;
